from PyQt6.QtWidgets import QApplication
from ui.main_window import MainWindow
import sys

if __name__ == "__main__":
    # ---------------- Start PyQt app ----------------
    app = QApplication(sys.argv)
    window = MainWindow()
    window.showMaximized()
    
    # ---------------- Run application ----------------
    exit_code = app.exec()
    sys.exit(exit_code)
