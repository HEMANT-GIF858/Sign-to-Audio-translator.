from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QStackedWidget
from ui.specially_abled_ui import SpeciallyAbledUI
from ui.normal_ui import NormalUI  # Make sure this exists

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Bidirectional STA Translator")
        self.resize(1200, 800)  # Optional default size

        main_layout = QVBoxLayout()
        self.setLayout(main_layout)

        # ---------- Navbar ----------
        navbar = QHBoxLayout()
        self.btn_specially_abled = QPushButton("Specially Abled UI")
        self.btn_normal = QPushButton("Normal UI")

        self.btn_specially_abled.setCheckable(True)
        self.btn_normal.setCheckable(True)
        self.btn_specially_abled.setChecked(True)  # Default

        navbar.addWidget(self.btn_specially_abled)
        navbar.addWidget(self.btn_normal)
        main_layout.addLayout(navbar)

        # ---------- Stacked Widget for switching UIs ----------
        self.stack = QStackedWidget()
        self.specially_abled_ui = SpeciallyAbledUI()
        self.normal_ui = NormalUI()

        self.stack.addWidget(self.specially_abled_ui)  # index 0
        self.stack.addWidget(self.normal_ui)           # index 1

        main_layout.addWidget(self.stack)

        # ---------- Button Logic ----------
        self.btn_specially_abled.clicked.connect(self.show_specially_abled)
        self.btn_normal.clicked.connect(self.show_normal)

    def show_specially_abled(self):
        self.stack.setCurrentIndex(0)
        self.btn_specially_abled.setChecked(True)
        self.btn_normal.setChecked(False)

    def show_normal(self):
        self.stack.setCurrentIndex(1)
        self.btn_normal.setChecked(True)
        self.btn_specially_abled.setChecked(False)
