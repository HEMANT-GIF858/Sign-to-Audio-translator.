from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTextEdit, QSizePolicy
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QColor, QPalette, QFont, QImage, QPixmap, QPainter
import cv2
from logic.finger_count import count_fingers
from logic.gesture_mapping import mapping
from logic.suggestions import get_suggestions
from logic.mediapipe_handler import hands, mp_hands, mp_draw
from websocket.client import send_message
from threading import Thread
import asyncio
import time

# ---------------- Centered QTextEdit ----------------
class CenteredTextEdit(QTextEdit):
    def __init__(self, text="", font_size=14, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setReadOnly(True)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setFont(QFont("Arial", font_size))
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        palette = self.palette()
        palette.setColor(QPalette.ColorRole.Text, QColor("white"))
        palette.setColor(QPalette.ColorRole.Base, Qt.GlobalColor.transparent)
        self.setPalette(palette)

        self.setStyleSheet("""
            QTextEdit {
                background: transparent;
                border: 2px solid #555555;
                border-radius: 6px;
                color: white;
            }
        """)
        self.setText(text)

# ---------------- Main UI ----------------
class SpeciallyAbledUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowState(Qt.WindowState.WindowMaximized)

        # ---------------- Layouts ----------------
        main_layout = QVBoxLayout()

        # Top: Camera feed + suggestions
        top_layout = QHBoxLayout()

        # -------- Camera Feed --------
        camera_container = QWidget()
        camera_layout = QVBoxLayout(camera_container)
        camera_layout.setContentsMargins(0, 0, 0, 0)

        self.camera_label = QLabel()
        self.camera_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.camera_label.setStyleSheet("""
            background-color: black;
            border-radius: 8px;
        """)
        self.camera_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.camera_label.setScaledContents(True)  # 🔹 Allow full scaling to fill area

        camera_layout.addWidget(self.camera_label)
        top_layout.addWidget(camera_container, stretch=3)

        # -------- Suggestions --------
        suggestion_widget = QWidget()
        suggestion_layout = QVBoxLayout()
        suggestion_layout.setSpacing(5)
        self.suggestion_boxes = []
        for i in range(4):
            box = CenteredTextEdit("", font_size=16)
            self.suggestion_boxes.append(box)
            suggestion_layout.addWidget(box, stretch=1)
        suggestion_widget.setLayout(suggestion_layout)
        top_layout.addWidget(suggestion_widget, stretch=1)

        main_layout.addLayout(top_layout, stretch=3)

        # Bottom: Current Word & Full Message
        bottom_layout = QVBoxLayout()
        self.word_box = CenteredTextEdit("", font_size=18)
        bottom_layout.addWidget(self.word_box, stretch=1)
        self.message_box = CenteredTextEdit("", font_size=18)
        bottom_layout.addWidget(self.message_box, stretch=2)

        main_layout.addLayout(bottom_layout, stretch=1)

        self.setLayout(main_layout)

        # ---------------- Camera Setup ----------------
        self.cap = cv2.VideoCapture(0)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)

        # ---------------- Internal State ----------------
        self.current_word = ""
        self.last_char = ""
        self.stable_pair = None
        self.stable_start_time = 0
        self.STABLE_THRESHOLD = 0.8
        self.char_detected = False

        # WebSocket URI for sending messages
        self.websocket_uri = "ws://localhost:8765"

    # ---------------- Frame Update ----------------
    def update_frame(self):
        if not hasattr(self, 'cap') or not self.cap.isOpened():
            return

        success, img = self.cap.read()
        if not success:
            return

        img = cv2.flip(img, 1)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        results = hands.process(img_rgb)

        detected_char = None
        left_value, right_value = None, None

        if results.multi_hand_landmarks and len(results.multi_hand_landmarks) == 2:
            for i, handLms in enumerate(results.multi_hand_landmarks):
                label = results.multi_handedness[i].classification[0].label
                count = count_fingers(handLms, label)
                if label == "Left":
                    left_value = count
                elif label == "Right":
                    right_value = count
                mp_draw.draw_landmarks(img, handLms, mp_hands.HAND_CONNECTIONS)

            if left_value is not None and right_value is not None:
                pair = (left_value, right_value)
                current_time = time.time()

                if pair != self.stable_pair:
                    self.stable_pair = pair
                    self.stable_start_time = current_time
                    self.char_detected = False
                else:
                    if not self.char_detected:
                        if current_time - self.stable_start_time >= self.STABLE_THRESHOLD:
                            detected_char = mapping.get(pair, "")
                            self.char_detected = True

        # Handle Detected Character
        if detected_char:
            if detected_char.startswith("SUGG") and self.current_word.strip():
                idx = int(detected_char[-1]) - 1
                suggestions = get_suggestions(self.current_word)
                if idx < len(suggestions) and suggestions[idx]:
                    self.current_word = suggestions[idx]
            elif detected_char == "SPACE":
                if self.current_word.strip():
                    text = self.message_box.toPlainText()
                    self.message_box.setPlainText((text + " " + self.current_word) if text else self.current_word)
                    self.current_word = ""
            elif detected_char == "CLEAR":
                self.current_word = self.current_word[:-1]
            elif detected_char == "SEND":
                if self.message_box.toPlainText().strip():
                    # Send message to normal UI
                    Thread(target=lambda: asyncio.run(send_message(self.message_box.toPlainText())), daemon=True).start()
                    self.message_box.setPlainText("")
                    self.current_word = ""
            else:
                self.current_word += detected_char

            self.word_box.setPlainText(self.current_word)
            self.last_char = detected_char

        # Update Suggestions
        suggestions = get_suggestions(self.current_word)
        for i, box in enumerate(self.suggestion_boxes):
            box.setPlainText(f'{i+1}. ' + suggestions[i] if suggestions[i] else "")

        # Display Camera
        h, w, _ = img.shape
        bytes_per_line = 3 * w
        qt_img = QImage(img.data, w, h, bytes_per_line, QImage.Format.Format_BGR888)

        # Get label dimensions
        label_w = self.camera_label.width()
        label_h = self.camera_label.height()

        # Scale pixmap while keeping aspect ratio
        pixmap = QPixmap.fromImage(qt_img).scaled(
            label_w,
            label_h,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )

        # Create a black pixmap same size as label to serve as background
        final_pixmap = QPixmap(label_w, label_h)
        final_pixmap.fill(Qt.GlobalColor.black)

        # Center the camera pixmap on the black background
        painter = QPainter(final_pixmap)
        painter.drawPixmap(
            (label_w - pixmap.width()) // 2,
            (label_h - pixmap.height()) // 2,
            pixmap
        )
        painter.end()

        self.camera_label.setPixmap(final_pixmap)


    # ---------------- Close Event ----------------
    def closeEvent(self, event):
        if hasattr(self, 'cap') and self.cap.isOpened():
            self.cap.release()
        event.accept()
