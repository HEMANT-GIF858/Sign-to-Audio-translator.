import sys
import asyncio
import websockets
from threading import Thread
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QApplication
from PyQt6.QtCore import Qt, QMetaObject, Q_ARG
from PyQt6.QtGui import QFont

WEBSOCKET_URI = "ws://localhost:8765"

class NormalUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Normal User Interface")

        layout = QVBoxLayout()
        layout.setSpacing(20)

        # Title
        self.status_label = QLabel("Messages from Specially Abled User")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setStyleSheet("background-color: gray; color: white;")
        self.status_label.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        layout.addWidget(self.status_label)

        # Receiver label
        self.receiver_label = QLabel("")
        self.receiver_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.receiver_label.setWordWrap(True)
        self.receiver_label.setStyleSheet(
            "background-color: black; color: white; padding: 20px; border-radius: 10px;"
        )
        self.receiver_label.setFont(QFont("Arial", 28, QFont.Weight.Bold))
        layout.addWidget(self.receiver_label, stretch=1)

        self.setLayout(layout)

        # Start WebSocket listener
        Thread(target=self.websocket_listener, daemon=True).start()

    def update_label(self, text):
        QMetaObject.invokeMethod(
            self.receiver_label,
            "setText",
            Qt.ConnectionType.QueuedConnection,
            Q_ARG(str, text)
        )

    async def ws_receive(self):
        try:
            async with websockets.connect(WEBSOCKET_URI) as ws:
                print("Connected to WebSocket server.")
                async for message in ws:
                    print("Sent:", message)
                    self.update_label(message)
        except Exception as e:
            print("WebSocket receive error:", e)

    def websocket_listener(self):
        asyncio.run(self.ws_receive())

# Run app
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = NormalUI()
    window.resize(800, 600)
    window.show()
    sys.exit(app.exec())
