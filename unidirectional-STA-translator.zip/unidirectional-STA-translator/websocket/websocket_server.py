import asyncio
import websockets
import subprocess
import sys

# ---- Text to Speech ----
USE_WIN32 = False
try:
    import win32com.client
    USE_WIN32 = True
except Exception:
    USE_WIN32 = False

def speak_with_win32(text: str):
    speaker = win32com.client.Dispatch("SAPI.SpVoice")
    speaker.Speak(str(text))

def speak_with_powershell(text: str):
    safe = str(text).replace("'", "''")
    ps = f"Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak('{safe}');"
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=False)

def speak(text: str):
    if not text:
        return
    if USE_WIN32:
        try:
            speak_with_win32(text)
            return
        except Exception as e:
            print("win32 speak failed:", e, file=sys.stderr)
    speak_with_powershell(text)

# ---- WebSocket Server ----
clients = set()

async def handle_connection(ws):
    clients.add(ws)
    try:
        async for message in ws:
            print("Received:", message)
            # Speak locally
            speak(message)
            # Broadcast to other clients
            disconnected = []
            for client in clients:
                if client != ws:
                    try:
                        await client.send(message)
                    except:
                        disconnected.append(client)
            for dc in disconnected:
                clients.remove(dc)
    finally:
        clients.remove(ws)

async def main():
    server_host = "0.0.0.0"
    server_port = 8765
    async with websockets.serve(handle_connection, server_host, server_port):
        print(f"WebSocket server running on ws://{server_host}:{server_port}")
        await asyncio.Future()  # keep running forever

if __name__ == "__main__":
    asyncio.run(main())
