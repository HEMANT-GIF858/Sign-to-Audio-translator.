import websockets

uri = "ws://localhost:8765"

async def send_message(msg):
    try:
        async with websockets.connect(uri) as ws:
            await ws.send(msg)
    except Exception as e:
        print("WebSocket send error:", e)
