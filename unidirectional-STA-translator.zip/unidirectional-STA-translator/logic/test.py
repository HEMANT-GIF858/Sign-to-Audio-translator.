import statistics
from suggestions import get_suggestions

# --- Predefined Dataset: word → shorthand / phonetic short form ---
# You can expand this list as much as you like
word_shortforms = {
    "apple": "aple",
    "application": "appl",
    "apply": "aply",
    "banana": "bnna",
    "band": "bnd",
    "bank": "bnk",
    "basket": "bskt",
    "book": "bok",
    "bottle": "bttl",
    "bridge": "brdg",
    "brother": "bro",
    "camera": "cam",
    "camp": "cmp",
    "candle": "cndl",
    "candy": "cdy",
    "capital": "capi",
    "card": "crd",
    "care": "car",
    "carry": "crry",
    "interview": "intrw",
    "cattle": "catl",
    "tomorrow": "tmrw",
    "change": "chng",
    "channel": "chnl",
    "charge": "chrg",
    "chart": "cht",
    "check": "chk",
    "child": "chld",
    "city": "cty",
    "class": "cls",
    "clean": "cln",
    "clear": "clr",
    "clock": "clok",
    "cloth": "clt",
    "cloud": "clod",
    "coffee": "cof",
    "cold": "cld",
    "color": "col",
    "company": "cpny",
    "computer": "cmpt",
    "control": "cntl",
    "copy": "cpy",
    "country": "cnty",
    "course": "crse",
    "cover": "cvr",
    "create": "crt",
    "credit": "crdt",
    "cross": "crs",
    "crowd": "cwd",
    "culture": "cltr",
    "current": "crnt",
    "customer": "cstmr",
    "dance": "dnc",
    "danger": "dngr",
    "dark": "drk",
    "data": "dat",
    "day": "dy",
    "deal": "dl",
    "death": "dth",
    "decision": "dcsn",
    "deep": "dp",
    "degree": "dgre",
    "design": "dsgn",
    "desk": "dsk",
    "develop": "dvlop",
    "direction": "dir",
    "door": "doo",
    "dream": "drm",
    "drive": "dri",
    "earth": "erth",
    "easy": "esy",
    "education": "edutn",
    "effect": "efc",
    "energy": "ener",
    "engine": "engn",
    "evening": "evng",
    "event": "evnt",
    "example": "exmp",
    "exchange": "exch",
    "experience": "expe",
    "eye": "eye",
    "face": "fac",
    "fact": "fct",
    "family": "fmly",
    "farm": "frm",
    "father": "fthr",
    "field": "fld",
    "fight": "fght",
    "film": "flm",
    "final": "finl",
    "fire": "fre",
    "fish": "fsh",
    "floor": "flor",
    "flower": "flwr",
    "food": "fod",
    "hello": "hlo",
    "force": "frce",
    "form": "frm",
    "friend": "frn",
    "front": "frt"
}


def test_phonetic_word_suggestions():
    results = []
    total = len(word_shortforms)

    for word, short in word_shortforms.items():
        suggestions = get_suggestions(short)[:4]
        success = word in suggestions

        efficiency = 100 if success else 0
        results.append({
            "word": word,
            "short": short,
            "success": success,
            "efficiency": efficiency
        })

    efficiencies = [r["efficiency"] for r in results]
    avg_eff = statistics.mean(efficiencies)
    med_eff = statistics.median(efficiencies)

    print("\n--- Word Suggestion Accuracy Evaluation (Phonetic Shortforms) ---")
    print(f"Total Words Tested: {total}")
    print(f"Average Accuracy: {avg_eff:.2f}%")
    print(f"Median Accuracy: {med_eff:.2f}%")
    print(f"Correctly Predicted: {sum(r['success'] for r in results)} / {total}")

    print("\nSample Results:")
    print(f"{'Word':<15}{'Short':<10}{'Top-4 Match'}")
    print("-" * 35)
    for r in results[:20]:
        print(f"{r['word']:<15}{r['short']:<10}{'✔' if r['success'] else '✖'}")

    return results, avg_eff


if __name__ == "__main__":
    results, avg_eff = test_phonetic_word_suggestions()
