import nltk
from nltk.corpus import brown
from collections import Counter
from rapidfuzz import fuzz

nltk.download('brown', quiet=True)

# --- Prepare word list and frequencies ---
common_words = [w.lower() for w in brown.words() if w.isalpha()]
word_counts = Counter(common_words)
common_words_sorted = sorted(word_counts.keys(), key=lambda x: -word_counts[x])
max_count = max(word_counts.values())
freq_scores = {w: word_counts[w]/max_count for w in common_words_sorted}


def is_subsequence(small, big):
    """Check if all characters of `small` appear in `big` in order."""
    it = iter(big)
    return all(c in it for c in small)


def get_suggestions(current_word, top_k=4, alpha=0.7):
    if not current_word:
        return [""] * top_k

    current_word_lower = current_word.lower()

    # First priority: exact prefix matches
    prefix_matches = [w for w in common_words_sorted if w.startswith(current_word_lower)]

    # Second priority: subsequence matches (the word must include all chars in order)
    subseq_matches = [
        w for w in common_words_sorted
        if is_subsequence(current_word_lower, w)
    ]

    # Only top 10k frequent words for efficiency
    candidates = subseq_matches[:10000]

    # Compute combined fuzzy+frequency score
    scores = []
    for word in candidates:
        if word in prefix_matches:
            continue
        sim = fuzz.ratio(current_word_lower, word)
        freq_score = freq_scores[word] * 100
        combined_score = alpha * sim + (1 - alpha) * freq_score
        scores.append((combined_score, word))

    # Sort by descending combined score
    scores.sort(key=lambda x: -x[0])

    # Combine: prefix matches first, then fuzzy subsequence matches
    suggestions = prefix_matches + [w for _, w in scores[:top_k - len(prefix_matches)]]

    # Pad to top_k
    while len(suggestions) < top_k:
        suggestions.append("")

    return suggestions
