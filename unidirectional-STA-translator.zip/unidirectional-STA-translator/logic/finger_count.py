def count_fingers(hand_landmarks, handedness):
    tips = [4, 8, 12, 16, 20]
    fingers = 0
    if handedness == "Right":
        if hand_landmarks.landmark[tips[0]].x < hand_landmarks.landmark[tips[0]-1].x:
            fingers += 1
    else:
        if hand_landmarks.landmark[tips[0]].x > hand_landmarks.landmark[tips[0]-1].x:
            fingers += 1
    for i in range(1,5):
        if hand_landmarks.landmark[tips[i]].y < hand_landmarks.landmark[tips[i]-2].y:
            fingers += 1
    return fingers
